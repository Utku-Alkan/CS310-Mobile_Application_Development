package com.sabanciuniv.controller;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sabanciuniv.model.Account;
import com.sabanciuniv.model.AccountCreateReturn;
import com.sabanciuniv.model.IncomingReturn;
import com.sabanciuniv.model.OutgoingReturn;
import com.sabanciuniv.model.RequestTransaction;
import com.sabanciuniv.model.Summary;
import com.sabanciuniv.model.SummaryReturn;
import com.sabanciuniv.model.Transaction;
import com.sabanciuniv.model.TransactionCreateReturn;
import com.sabanciuniv.repo.AccountRepository;
import com.sabanciuniv.repo.TransactionRepository;

@RestController
public class BankRestController {
	
	@Autowired private AccountRepository accountRepository;
	@Autowired private TransactionRepository transactionRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(BankRestController.class);
	
	
	
	@PostConstruct
	public void init() {
		if(accountRepository.count()==0) {
			logger.info("Database is empty, initializing..");
			Account acc1 = new Account("1111", "Jack Johns", LocalDateTime.now());
			Account acc2 = new Account("2222", "Henry Williams", LocalDateTime.now());
			
			accountRepository.save(acc1);
			accountRepository.save(acc2);
			
			Transaction transaction1 = new Transaction(acc1, acc2, 1500);
			Transaction transaction2 = new Transaction(acc2, acc1, 2500);
			
			
			transactionRepository.save(transaction1);
			transactionRepository.save(transaction2);
			
			logger.info("All data saved!");
			
		}
	}
	
	@GetMapping("/account")
	public List<Account> accounts(){
		return accountRepository.findAll();
	}
	@GetMapping("/transaction")
	public List<Transaction> transactions(){
		return transactionRepository.findAll();
	}
	
	
	@PostMapping("/account/save")
	public AccountCreateReturn saveAccount(@RequestBody Account account) {
		AccountCreateReturn returned = new AccountCreateReturn();
		
		if(account.getId() == null || account.getOwner() == null) { //handled later
			returned.setMessage("ERROR:missing fields");
			returned.setData(null);
		}else {
			account.setCreateDate(LocalDateTime.now());
			Account accountSaved = accountRepository.save(account);
			returned.setMessage("SUCCESS");
			returned.setData(accountSaved);
		}
		return returned; 
	}
	
	@PostMapping("/transaction/save")
	public TransactionCreateReturn saveTransaction(@RequestBody RequestTransaction requestTransaction) {	
		String from = requestTransaction.getFromAccountId();
		String to = requestTransaction.getToAccountId();
		if(from == null || to == null || requestTransaction.getAmount() == 0) {
			TransactionCreateReturn transactionCreateReturn = new TransactionCreateReturn("ERROR:missing fields",null);
			return transactionCreateReturn;
		}else {
			
			Optional<Account> accChecker1 = accountRepository.findById(from);
			Optional<Account> accChecker2 = accountRepository.findById(to);
			
			if(accChecker1.isEmpty() || accChecker2.isEmpty()) {
				TransactionCreateReturn transactionCreateReturn = new TransactionCreateReturn("ERROR: account id",null);
				return transactionCreateReturn;
			}else {
				
				Account acc1 = accountRepository.findById(from).get();
				Account acc2 = accountRepository.findById(to).get();
				Transaction transaction = new Transaction(acc1, acc2, requestTransaction.getAmount());
				Transaction accountSaved = transactionRepository.save(transaction);
				TransactionCreateReturn transactionCreateReturn = new TransactionCreateReturn("SUCCESS",accountSaved);
				return transactionCreateReturn;
			}
		}
		
	}	
	
	@GetMapping("/account/{accountId}")
	public SummaryReturn accountSummaryReturn(@PathVariable String accountId) {
		
		Optional<Account> acc = accountRepository.findById(accountId);
		if(acc.isEmpty()) {
			SummaryReturn summaryReturn = new SummaryReturn("ERROR:account doesnt exist!", null);
			return summaryReturn;
		}else {
			Account account = accountRepository.findById(accountId).get();
			List<Transaction> froms = transactionRepository.findByFrom(account);
			List<Transaction> tos = transactionRepository.findByTo(account);
			int fromAmount = 0;
			int toAmount = 0;
			for (Transaction element : froms) {
			    fromAmount = fromAmount + (int) element.getAmount();
			}
			
			for (Transaction element : tos) {
			    toAmount = toAmount + (int) element.getAmount();
			}
			int mybalance = toAmount - fromAmount;
			Summary summary = new Summary(accountId, account.getOwner(), froms, tos, mybalance);
			SummaryReturn summaryReturn = new SummaryReturn("SUCCESS", summary);
			return summaryReturn;
		}
	}	
	
	@GetMapping("/transaction/to/{accountId}")
	public IncomingReturn accountIncomingReturn(@PathVariable String accountId) {
	
		Optional<Account> acc = accountRepository.findById(accountId);
		
		if(acc.isEmpty()) {
			IncomingReturn incomingReturn = new IncomingReturn("ERROR:account doesn’t exist", null);
			return incomingReturn;
		}else {
			Account account = accountRepository.findById(accountId).get();
			List<Transaction> tos = transactionRepository.findByTo(account);
			IncomingReturn incomingReturn = new IncomingReturn("SUCCESS", tos);
			return incomingReturn;
		}	
	}
	
	@GetMapping("/transaction/from/{accountId}")
	public OutgoingReturn accountOutgoingReturn(@PathVariable String accountId) {
	
		Optional<Account> acc = accountRepository.findById(accountId);
		
		if(acc.isEmpty()) {
			OutgoingReturn outgoingReturn = new OutgoingReturn("ERROR:account doesn’t exist", null);
			return outgoingReturn;
		}else {
			Account account = accountRepository.findById(accountId).get();
			List<Transaction> froms = transactionRepository.findByFrom(account);
			OutgoingReturn outgoingReturn = new OutgoingReturn("SUCCESS", froms);
			return outgoingReturn;
		}	
	}
}
