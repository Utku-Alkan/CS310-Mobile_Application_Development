package com.sabanciuniv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtkuAlkanApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtkuAlkanApplication.class, args);
	}

}
