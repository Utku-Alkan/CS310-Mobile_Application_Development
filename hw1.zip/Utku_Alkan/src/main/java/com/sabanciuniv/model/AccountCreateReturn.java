package com.sabanciuniv.model;

public class AccountCreateReturn {
	private String message;
	private Account data;
	
	
	public AccountCreateReturn() {
		
	}

	public AccountCreateReturn(String message, Account data) {
		super();
		this.message = message;
		this.data = data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Account getData() {
		return data;
	}

	public void setData(Account data) {
		this.data = data;
	}
	
	
	
}
