package com.sabanciuniv.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RequestTransaction {
	
	private double amount = 0;
	private String fromAccountId;
	private String toAccountId; 
	
	
	
	
	public RequestTransaction() {
		super();
	}
	public RequestTransaction(String fromAccountId, String toAccountId, double amount) {
		super();
		this.fromAccountId = fromAccountId;
		this.toAccountId = toAccountId;
		this.amount = amount;
	}
	
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getFromAccountId() {
		return fromAccountId;
	}
	public void setFromAccountId(String fromAccountId) {
		this.fromAccountId = fromAccountId;
	}
	public String getToAccountId() {
		return toAccountId;
	}
	public void setToAccountId(String toAccountId) {
		this.toAccountId = toAccountId;
	}
	@Override
	public String toString() {
		return "RequestTransaction [fromAccountId=" + fromAccountId + ", toAccountId=" + toAccountId + ", amount="
				+ amount + "]";
	}
	
}
