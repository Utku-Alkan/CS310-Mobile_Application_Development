package com.sabanciuniv.model;

import java.time.LocalDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Transaction {
	private String id;
	private Account from;
	private Account to;
	private LocalDateTime createDate; 
	private double amount = 0;
	
	
	public Transaction() {
		
	}

	public Transaction(Account acc1, Account acc2, double amount) {
		super();	
		this.from = acc1;
		this.to = acc2;
		this.createDate = LocalDateTime.now();
		this.amount = amount;
	}

	public Transaction(String id, Account acc1, Account acc2, double amount) {
		super();	
		this.id = id;
		this.from = acc1;
		this.to = acc2;
		this.createDate = LocalDateTime.now();
		this.amount = amount;
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account getFrom() {
		return from;
	}
	public void setFrom(Account from) {
		this.from = from;
	}
	public Account getTo() {
		return to;
	}
	public void setTo(Account to) {
		this.to = to;
	}




	public LocalDateTime getCreateDate() {
		return createDate;
	}




	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	
}

	
