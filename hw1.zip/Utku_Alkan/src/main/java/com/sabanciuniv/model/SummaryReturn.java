package com.sabanciuniv.model;

public class SummaryReturn {
	private String message;
	private Summary data;
	
	
	public SummaryReturn() {
		super();
	}
	
	public SummaryReturn(String message, Summary data) {
		super();
		this.message = message;
		this.data = data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Summary getData() {
		return data;
	}

	public void setData(Summary data) {
		this.data = data;
	}
	
	
	
}
