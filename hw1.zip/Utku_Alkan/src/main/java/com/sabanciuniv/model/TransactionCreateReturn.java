package com.sabanciuniv.model;

public class TransactionCreateReturn {
	private String message;
	private Transaction data;
	
	
	public TransactionCreateReturn() {
		super();
	}



	public TransactionCreateReturn(String message, Transaction data) {
		super();
		this.message = message;
		this.data = data;
	}



	public String getMessage() {
		return message;
	}




	public void setMessage(String message) {
		this.message = message;
	}




	public Transaction getData() {
		return data;
	}




	public void setData(Transaction data) {
		this.data = data;
	}
	
	
	
	
}
