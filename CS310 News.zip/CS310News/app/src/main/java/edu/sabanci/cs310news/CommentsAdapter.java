package edu.sabanci.cs310news;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder> {


    private Context ctx;
    private List<Comments> data;

    public CommentsAdapter(Context ctx, List<Comments> data) {
        this.ctx = ctx;
        this.data = data;
    }


    @NonNull
    @Override
    public CommentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View root= LayoutInflater.from(ctx).inflate(R.layout.comments_row_layout,parent,false);

        CommentsAdapter.CommentsViewHolder holder = new CommentsAdapter.CommentsViewHolder(root);
        holder.setIsRecyclable(false);
        return holder;

    }





    @Override
    public void onBindViewHolder(@NonNull CommentsAdapter.CommentsViewHolder holder, int position) {

        holder.commentName.setText(data.get(holder.getAdapterPosition()).getName());
        holder.commentText.setText(data.get(holder.getAdapterPosition()).getTest());



        /*holder.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx,ActivityDetails.class);
                i.putExtra("id",data.get(holder.getAdapterPosition()).getId());
                ctx.startActivity(i);


            }
        }); //commentlere tiklanmasin */

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class CommentsViewHolder extends RecyclerView.ViewHolder{

        TextView commentName;
        TextView commentText;
        ConstraintLayout row;




        public CommentsViewHolder(@NonNull View itemView) {
            super(itemView);
            commentName = itemView.findViewById(R.id.commentName);
            commentText = itemView.findViewById(R.id.commentText);
            row = itemView.findViewById(R.id.comment_row_list);

        }
    }



}
