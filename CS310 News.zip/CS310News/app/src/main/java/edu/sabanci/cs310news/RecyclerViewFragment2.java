package edu.sabanci.cs310news;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import java.util.List;


public class RecyclerViewFragment2 extends Fragment {

    ProgressBar prg;
    RecyclerView recView;


    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<News> data = (List<News>)msg.obj;
            NewsAdapter adp = new NewsAdapter(RecyclerViewFragment2.this.getActivity(),data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);


        View v = inflater.inflate(R.layout.fragment_recycler_view, container, false);


        prg = v.findViewById(R.id.progressBarList);
        recView = v.findViewById(R.id.fragmentRecycle);
        recView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        NewsRepository repo = new NewsRepository();
        repo.getDataByCategoryId(((NewsApp) RecyclerViewFragment2.this.getActivity().getApplication()).srv, dataHandler,2);






        // Inflate the layout for this fragment
        return v;
    }

}