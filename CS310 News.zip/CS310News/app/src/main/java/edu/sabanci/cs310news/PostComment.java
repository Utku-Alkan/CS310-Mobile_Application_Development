package edu.sabanci.cs310news;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;

public class PostComment extends AppCompatActivity {


    EditText editName;
    EditText editComment;
    Button postComment;
    ProgressBar progressBar;
    TextView warning;

    Handler postCommentHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            String val = message.obj.toString();

            // do the post             txtOutput.setText(retVal);
            progressBar.setVisibility(View.INVISIBLE);

            return true;
        }
    });



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Post Comment");

        int id = getIntent().getIntExtra("key",1);

        editName = findViewById(R.id.editTextName);
        editComment = findViewById(R.id.editTextComments);
        postComment = findViewById(R.id.btn_post_comment);
        progressBar = findViewById(R.id.progressBarPost);
        warning = findViewById(R.id.warning);

        postComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);

                String name = editName.getText().toString();
                String comment = editComment.getText().toString();

                if(name.equals("") || comment.equals("")){
                    progressBar.setVisibility(View.INVISIBLE);
                    warning.setVisibility(View.VISIBLE);

                }else {
                    warning.setVisibility(View.INVISIBLE);
                    NewsRepository repo = new NewsRepository();

                    repo.postCommentJson(((NewsApp) getApplication()).srv, postCommentHandler, name, comment, id);
                    /*Intent myIntent = new Intent(PostComment.this, CommentsActivity.class);
                    myIntent.putExtra("key", id); //Optional parameters
                    myIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                    PostComment.this.startActivity(myIntent);*/

                    finish();

                }

            }
        });

    }





    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}