package edu.sabanci.cs310news;

public class Comments {
    private int id, news_id;
    private String test, name;

    public Comments(int id, int news_id, String test, String name) {
        this.id = id;
        this.news_id = news_id;
        this.test = test;
        this.name = name;
    }

    public Comments() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNews_id() {
        return news_id;
    }

    public void setNews_id(int news_id) {
        this.news_id = news_id;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
