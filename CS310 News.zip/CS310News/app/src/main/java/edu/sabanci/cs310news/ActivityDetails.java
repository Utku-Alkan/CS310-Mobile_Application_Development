package edu.sabanci.cs310news;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class ActivityDetails extends AppCompatActivity {

    ImageView imgDetails;
    TextView textTitleDetails;
    TextView textDateDetails;
    TextView textTextDetails;
    int idFinder = 0;
    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            News haber = (News) msg.obj;

            textTitleDetails.setText(haber.getTitle());
            textDateDetails.setText(haber.getDate());
            textTextDetails.setText(haber.getText());
            idFinder = haber.getId();

            setTitle(haber.getCategoryName());


            NewsRepository repo = new NewsRepository();
            repo.downloadImage(((NewsApp)getApplication()).srv,imgHandler,haber.getImage());

            return true;
        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {

            Bitmap img = (Bitmap) msg.obj;
            imgDetails.setImageBitmap(img);

            return true;
        }
    });








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        int id = getIntent().getIntExtra("id",1);



        imgDetails =findViewById(R.id.imgDetails);
        textTitleDetails = findViewById(R.id.textTitleDetails);
        textDateDetails = findViewById(R.id.textDateDetails);
        textTextDetails = findViewById(R.id.textTextDetails);

        NewsRepository repo = new NewsRepository();
        repo.getDataById(((NewsApp)getApplication()).srv,dataHandler,id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            finish();
        }

        if (item.getItemId() == R.id.show_comments) {// Show comments
            Intent myIntent = new Intent(ActivityDetails.this, CommentsActivity.class);
            myIntent.putExtra("key", idFinder); //Optional parameters
            ActivityDetails.this.startActivity(myIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);

        //return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.detail_menu,menu);
        return true;
    }


}