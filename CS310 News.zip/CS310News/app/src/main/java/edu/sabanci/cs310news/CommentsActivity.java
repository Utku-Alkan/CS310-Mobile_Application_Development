package edu.sabanci.cs310news;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import java.util.List;

public class CommentsActivity extends AppCompatActivity {


    ProgressBar prg;
    RecyclerView recView;
    int idFinder = 0;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Comments> data = (List<Comments>)msg.obj;
            CommentsAdapter adp = new CommentsAdapter(CommentsActivity.this,data);
            recView.setAdapter(adp);
            recView.setVisibility(View.VISIBLE);
            prg.setVisibility(View.INVISIBLE);

            return true;
        }
    });



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);



        int id = getIntent().getIntExtra("key",1);

        idFinder = id;

        prg = findViewById(R.id.progressBarComments);
        recView = findViewById(R.id.recyclerViewComments);
        recView.setLayoutManager(new LinearLayoutManager(this));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        NewsRepository repo = new NewsRepository();
        repo.getCommentsByNewsId(((NewsApp) getApplication()).srv, dataHandler, id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Comments");


    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            finish();
        }

        if (item.getItemId() == R.id.post_comments) {// Show comments
            Intent myIntent = new Intent(CommentsActivity.this, PostComment.class);
            myIntent.putExtra("key", idFinder); //Optional parameters
            CommentsActivity.this.startActivity(myIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.post_menu,menu);
        return true;
    }


    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_comments);

        int id = getIntent().getIntExtra("key",1);

        idFinder = id;

        prg = findViewById(R.id.progressBarComments);
        recView = findViewById(R.id.recyclerViewComments);
        recView.setLayoutManager(new LinearLayoutManager(this));
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);

        NewsRepository repo = new NewsRepository();
        repo.getCommentsByNewsId(((NewsApp) getApplication()).srv, dataHandler, id);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Comments");
    }


}